package project3;

import javafx.scene.control.CheckBox;

public class Todo {
	private String taskTitle;
	private String notes;
	private String dueDate;
	private String difficulty;
	private CheckBox checkBox; 
 

	
	//constructor 
	public Todo(String taskTitle, String notes, String dueDate, String difficulty, CheckBox checkBox) {
		this.taskTitle = taskTitle;
		this.notes = notes;
		this.dueDate = dueDate;
		this.difficulty = difficulty;
		this.checkBox = checkBox; 
	
	}	
	
	//setter() 
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public void setTaskTitle(String taskTitle) {
		this.taskTitle = taskTitle;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
	public void setCheckBox(CheckBox checkBox) {
		this.checkBox = checkBox;
	}


	//getter() 
	public String getTaskTitle() {
		return taskTitle;
	}
	public String getDueDate() {
		return dueDate;
	}
	public String getNotes() {
		return notes;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public CheckBox getCheckBox() {
		return checkBox;
	}
}
