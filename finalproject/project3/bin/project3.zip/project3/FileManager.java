package project3;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class FileManager {

  public void saveCartToDisk(File file, ArrayList<Todo> cart) 
  {
    try (PrintWriter printWriter = new PrintWriter(file)) {
      for (Todo item : cart) {
        printWriter.println(item.getTaskTitle() + "," + item.getDueDate() + "," + item.getNotes() + "," + item.getDifficulty() + "," + item.getCheckBox());
      }
    } catch (Exception err) {
      System.out.println("ERROR - File not saved");
    }
  }
  
  public ArrayList <Todo> loadCartFromDisk (File file)
  {
    ArrayList <Todo> cart = new ArrayList<Todo>();
    try(Scanner scan = new Scanner(file)){
      while (scan.hasNextLine()) {
        String[] deflatedObjectParts = scan.nextLine().split(",");
        cart.add(new Todo(deflatedObjectParts[0], deflatedObjectParts[1], deflatedObjectParts[2], ));
      }
    }
    catch (Exception err)
    {
      System.out.println("Sorry, couldn't read file");
    }
    return cart;
  }

}
